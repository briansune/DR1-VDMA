//  ____         _                ____
// | __ )  _ __ (_)  __ _  _ __  / ___|  _   _  _ __    ___
// |  _ \ | '__|| | / _` || '_ \ \___ \ | | | || '_ \  / _ \
// | |_) || |   | || (_| || | | | ___) || |_| || | | ||  __/
// |____/ |_|   |_| \__,_||_| |_||____/  \__,_||_| |_| \___|
//
// Programed By: BrianSune
// Contact: briansune@gmail.com
//

#define DEMO_PATTERN_0 0
#define DEMO_PATTERN_1 1

#include "al_axi_vdma_hal.h"

AlAxiVdma_Hal_Struct *Vdma;
AlAxiVdma_ChannelCfg *Mm2sChannelCfg;
AlAxiVdma_ChannelCfg *S2MmChannelCfg;

volatile AL_BOOL TransFlag = 0;
AL_U8 ReadArray[1920*1080*4*1];

extern const unsigned char pm5644[6220800];
extern const unsigned char logo2[6220800];


static AL_VOID AlAxiVdma_EventHandler(AlAxiVdma_EventStruct VdmaEvent, AL_VOID *CallbackRef)
{
    switch (VdmaEvent.Events)
    {
    case ALAXIVDMA_EVENT_MM2S_FRAMECNT:
//        AL_LOG(AL_LOG_LEVEL_INFO, "Al AxiVdma Mm2s interrupt");
//        AlAxiVdma_Hal_Stop(Vdma, AL_VDMA_MM2S_CHANNEL);
        break;
    case ALAXIVDMA_EVENT_MM2S_ERRIRQ:
        AL_LOG(AL_LOG_LEVEL_INFO, "Al AxiVdma Mm2s error interrupt");
        AlAxiVdma_Hal_Stop(Vdma, AL_VDMA_MM2S_CHANNEL);
        break;
    case ALAXIVDMA_EVENT_S2MM_FRAMECNT:
        AL_LOG(AL_LOG_LEVEL_INFO, "Al AxiVdma S2Mm interrupt");
        TransFlag = 1;
        AlAxiVdma_Hal_Stop(Vdma, AL_VDMA_S2MM_CHANNEL);
        break;
    case ALAXIVDMA_EVENT_S2MM_ERRIRQ:
        AL_LOG(AL_LOG_LEVEL_INFO, "Al AxiVdma S2Mm error interrupt");
        TransFlag = 1;
        AlAxiVdma_Hal_Stop(Vdma, AL_VDMA_S2MM_CHANNEL);
        break;
    default:
        break;
    }
}

AL_VOID DemoPrintTest(AL_U8 *frame, int pattern){

	AL_U32 i,j;

	switch (pattern){

	case DEMO_PATTERN_0:

		for (i = 0; i < 1080; i++)
		{
			for (j = 0; j < 1920; j++)
			{
				frame[1920*4*i+4*j+3]=0x00;
				frame[1920*4*i+4*j+0]=logo2[1920*3*(1079-i)+3*j+0];
				frame[1920*4*i+4*j+1]=logo2[1920*3*(1079-i)+3*j+1];
				frame[1920*4*i+4*j+2]=logo2[1920*3*(1079-i)+3*j+2];
			}
		}

		AlCache_FlushDcacheRange(&frame[0], &frame[1920*1080*4]);
		break;
	case DEMO_PATTERN_1:

		for (i = 0; i < 1080; i++)
		{
			for (j = 0; j < 1920; j++)
			{
				frame[1920*4*i+4*j+3]=0x00;
				frame[1920*4*i+4*j+0]=pm5644[1920*3*(1079-i)+3*j+0];
				frame[1920*4*i+4*j+1]=pm5644[1920*3*(1079-i)+3*j+1];
				frame[1920*4*i+4*j+2]=pm5644[1920*3*(1079-i)+3*j+2];
			}
		}

		AlCache_FlushDcacheRange(&frame[0], &frame[1920*1080*4]);
		break;
	default :
		AL_LOG(AL_LOG_LEVEL_INFO, "Error: invalid pattern passed to DemoPrintTest");
	}
}

AL_VOID AxiVdmaLoopbackTest()
{
    AL_S32 Status;
	int i, j;

	for (i = 0; i < 1080; i++){
		for (j = 0; j < 1920; j++){

			ReadArray[1920*4*i+4*j]=pm5644[1920*3*(1079-i)+3*j+0];
			ReadArray[1920*4*i+4*j+1]=pm5644[1920*3*(1079-i)+3*j+1];
			ReadArray[1920*4*i+4*j+2]=pm5644[1920*3*(1079-i)+3*j+2];
			ReadArray[1920*4*i+4*j+3]=0x00;
		}
	}

//    AlCache_FlushDcacheRange(&ReadArray[0], &ReadArray[1920*1080*4]);
    AlCache_FlushDcacheAll();

    Mm2sChannelCfg = malloc(sizeof(AlAxiVdma_ChannelCfg));
    memset(Mm2sChannelCfg, 0, sizeof(AlAxiVdma_ChannelCfg));

//    S2MmChannelCfg = malloc(sizeof(AlAxiVdma_ChannelCfg));
//    memset(S2MmChannelCfg, 0, sizeof(AlAxiVdma_ChannelCfg));

    Mm2sChannelCfg->RepeatEn = 1;
    Mm2sChannelCfg->CircularPark = 1;
    Mm2sChannelCfg->FrameCount = 1;
    Mm2sChannelCfg->FrmCntIrqEn = 1;
    Mm2sChannelCfg->ErrIrqEn = 1;
    Mm2sChannelCfg->GenlockSrc = 1;
    Mm2sChannelCfg->GenlockEn = 0;
    Mm2sChannelCfg->Hsize = 1920 * 4;
    Mm2sChannelCfg->Vsize = 1080;
    Mm2sChannelCfg->Stride = 1920 * 4;
    Mm2sChannelCfg->FrameStoreStartAddr[0]= &ReadArray[0];
//    Mm2sChannelCfg->FrameStoreStartAddr[1]= &ReadArray[1920*1080*4*1];
//    Mm2sChannelCfg->FrameStoreStartAddr[2]= &ReadArray[1920*1080*4*2];

    AlIntr_SetLocalInterrupt(AL_FUNC_ENABLE);

    AlAxiVdma_Hal_Init(&Vdma, 0, AlAxiVdma_EventHandler);

    AlAxiVdma_Hal_Start(Vdma, AL_VDMA_MM2S_CHANNEL, Mm2sChannelCfg);
//    AlAxiVdma_Hal_Start(Vdma, AL_VDMA_S2MM_CHANNEL, S2MmChannelCfg);

    while(1)
	{
		DemoPrintTest(ReadArray, DEMO_PATTERN_0);
		AlSys_MDelay(5000);

		DemoPrintTest(ReadArray, DEMO_PATTERN_1);
		AlSys_MDelay(5000);
	}
}

AL_S32 main()
{
    AL_U32 Val = 0;
    AL_S32 ret = AL_OK;
    AL_BOOL IsEqual = AL_TRUE;

    AL_LOG(AL_LOG_LEVEL_INFO, "Axi vdma loopback test!");

    Soc_PsPlInit();

    AxiVdmaLoopbackTest();

    return 0;
}
